package io.flutter.plugins.url_launcher_macos;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.PluginRegistry.Registrar;

public class UrlLauncherMacosPlugin implements FlutterPlugin {
  @Override
  public void onAttachedToEngine(FlutterPluginBinding flutterPluginBinding) {}

  public static void registerWith(Registrar registrar) {}

  @Override
  public void onDetachedFromEngine(FlutterPluginBinding binding) {}
}
